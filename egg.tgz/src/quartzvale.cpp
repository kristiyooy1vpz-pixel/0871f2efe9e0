// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Survey quartzvale\n", stdout);
  return lionss_run_workload("quartzvale");
}
