// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Stabilize kestrel hover\n", stdout);
  return lionss_run_workload("Kestrel");
}
