// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Linear-scan allocate\n", stdout);
  return lionss_run_workload("regalloclinear");
}
