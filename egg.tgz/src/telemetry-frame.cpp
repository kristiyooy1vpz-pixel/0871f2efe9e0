// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack telemetry frame"); }
int main(){
  announce();
  return lionss_run_workload("telemetry-frame");
}
