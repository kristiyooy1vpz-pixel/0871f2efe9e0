// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply branch hints\n", stdout);
  return lionss_run_workload("branchHint");
}
