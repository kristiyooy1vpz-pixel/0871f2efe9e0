# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(regalloclinear src/regalloclinear.cpp)
set_property(TARGET regalloclinear PROPERTY CXX_STANDARD 11)
target_link_libraries(regalloclinear lionss pthread)

add_executable(noiseGate src/noiseGate.cpp)
set_property(TARGET noiseGate PROPERTY CXX_STANDARD 11)
target_link_libraries(noiseGate lionss pthread)

add_executable(tickresample src/tickresample.cpp)
set_property(TARGET tickresample PROPERTY CXX_STANDARD 11)
target_link_libraries(tickresample lionss pthread)

add_executable(cedar_grove src/cedar_grove.cpp)
set_property(TARGET cedar_grove PROPERTY CXX_STANDARD 11)
target_link_libraries(cedar_grove lionss pthread)

add_executable(colorGamutP3 src/colorGamutP3.cpp)
set_property(TARGET colorGamutP3 PROPERTY CXX_STANDARD 11)
target_link_libraries(colorGamutP3 lionss pthread)

add_executable(gudgeon src/gudgeon.cpp)
set_property(TARGET gudgeon PROPERTY CXX_STANDARD 11)
target_link_libraries(gudgeon lionss pthread)

add_executable(wavpackHybrid src/wavpackHybrid.cpp)
set_property(TARGET wavpackHybrid PROPERTY CXX_STANDARD 11)
target_link_libraries(wavpackHybrid lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(pgo-merge src/pgo-merge.cpp)
set_property(TARGET pgo-merge PROPERTY CXX_STANDARD 11)
target_link_libraries(pgo-merge lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(ssrHydrate src/ssrHydrate.cpp)
set_property(TARGET ssrHydrate PROPERTY CXX_STANDARD 11)
target_link_libraries(ssrHydrate lionss pthread)

add_executable(quartzvale src/quartzvale.cpp)
set_property(TARGET quartzvale PROPERTY CXX_STANDARD 11)
target_link_libraries(quartzvale lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(coral-9 src/coral-9.cpp)
set_property(TARGET coral-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(coral-9 lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(telemetry-frame src/telemetry-frame.cpp)
set_property(TARGET telemetry-frame PROPERTY CXX_STANDARD 11)
target_link_libraries(telemetry-frame lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(apiBlueprint src/apiBlueprint.cpp)
set_property(TARGET apiBlueprint PROPERTY CXX_STANDARD 11)
target_link_libraries(apiBlueprint lionss pthread)

add_executable(TeensyDma src/TeensyDma.cpp)
set_property(TARGET TeensyDma PROPERTY CXX_STANDARD 11)
target_link_libraries(TeensyDma lionss pthread)

add_executable(Kestrel src/Kestrel.cpp)
set_property(TARGET Kestrel PROPERTY CXX_STANDARD 11)
target_link_libraries(Kestrel lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(ripgrep_glob src/ripgrep_glob.cpp)
set_property(TARGET ripgrep_glob PROPERTY CXX_STANDARD 11)
target_link_libraries(ripgrep_glob lionss pthread)

add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

